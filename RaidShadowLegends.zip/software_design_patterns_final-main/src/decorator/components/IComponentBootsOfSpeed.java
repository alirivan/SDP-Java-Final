package decorator.components;

public interface IComponentBootsOfSpeed {
    public abstract int cost();
    public abstract String getNotification();
}
