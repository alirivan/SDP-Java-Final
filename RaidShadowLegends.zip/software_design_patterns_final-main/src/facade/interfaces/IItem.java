package facade.interfaces;

public interface IItem {
    public void purchaseItem(String items);
    public String deliverItem();
}
