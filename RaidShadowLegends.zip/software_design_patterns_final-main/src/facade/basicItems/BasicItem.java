package facade.basicItems;

public class BasicItem {

    public String getEnergyBoosterItem() {
        return "Energy Booster";
    }

    public String getRecipeBootsOfTravel() {
        return "Recipe: Boots of Travel";
    }

    public String getBladesOfAttack() {
        return "Blades of Attack";
    }

    public String getBeltOfStrength() {
        return "Belt of Strength";
    }

    public String getGlovesOfHaste() {
        return "Gloves of Haste";
    }

    public String getRingOfRegen() {
        return "Ruby of Death";
    }

    public String getWindLace() {
        return "Wind Lace";
    }

    public int costEnergyBoosterItem() {
        return 900;
    }

    public int costRecipeBootsOfTravel() {
        return 2500;
    }

    public int costBladesOfAttack() {
        return 455;
    }

    public int costBeltOfStrength() {
        return 650;
    }

    public int costGlovesOfHaste() {
        return 250;
    }

    public int costRingOfRegen() {
        return 195;
    }

    public int costWindLace() {
        return 2250;
    }

}

