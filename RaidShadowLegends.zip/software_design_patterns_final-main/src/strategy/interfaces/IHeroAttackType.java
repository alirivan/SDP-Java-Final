package strategy.interfaces;

public interface IHeroAttackType {
    void attackType();
}
