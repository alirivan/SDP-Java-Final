package strategy.interfaces;

public interface IHeroComplexityBehaviour {
    void complexity();
}
