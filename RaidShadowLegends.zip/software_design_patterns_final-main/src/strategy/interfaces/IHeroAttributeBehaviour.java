package strategy.interfaces;

public interface IHeroAttributeBehaviour {
    void attribute();
}
